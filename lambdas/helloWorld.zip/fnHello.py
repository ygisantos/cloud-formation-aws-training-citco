
def handler(event, context):
    print("Hello World")
    
    return "hello world"